function [A,B ]= Haar_inv(M,D)
A=M+D/2;
B=M-D/2;
end