function [M,D ]= Haar(A,B)
M=(A+B)/2;
D=(A-B);
end