function Iw = rev_embed(I, w)
[M,N]=size(I);
[a,s]=size(w);
L=zeros(M,N/2);
H=zeros(M,N/2);
for i=1:M
    for j=1:2:N-1
        L(i,(j+1)/2)=floor((I(i,j)+I(i,j+1))/2);
        H(i,(j+1)/2)=I(i,j)-I(i,j+1);
    end
end %��forѭ���ǽ�ͼ���ź�תΪ�ߵ�Ƶ�ź�

for d=0:30 %��for��δʵ��ʹ��
    max=256; min=-1; %����������
    capacity=0; %����
    for i=1:M*N*0.5
        
        if abs(H(i))<=d %����Ƕ���ĸ�Ƶ����2009_sachnev
            if H(i)>=0
                th=H(i)*2+1;
            else
                th=H(i)*2;
            end
        else
            if H(i)>=0
                th=H(i)+d+1;
            else
                th=H(i)-d;
            end
        end
        %�ж��޸ĺ��th�Ƿ�ᵼ�����
        if th>2*(255-  L(i))  || th<  2*( L(i)-255)
            if max> L(i)
                max= L(i);
            end
        end
        if   th>2*(L(i)) +1 || th<  -2*L(i)-1
            if min< L(i)
                min= L(i);
            end
        end
        tt=L(1:i);
        cc=find(tt>min & tt<max);
        tt=H(cc);
        cc=find(abs(tt)<=d);
        [z,f]=size(cc);
        if f>s %s=1024=ˮӡ����
            Loc=i;
            del=d;
            capacity=f;
            SMax=max;
            SMin=min;
            break;
        end
    end
    if capacity>s
        break;
    end
end

if capacity>s
    k=1;
    for i=1:Loc
        if L(i)>SMin && L(i)<SMax
            if abs(H(i))<=del
                H(i)=H(i)*2+w(k);
                k=k+1;
                if k>s
                    break;
                end
            else
                if H(i)>=0
                    H(i)=H(i)+del+1;
                else
                    H(i)=H(i)-del;
                end
            end
        end
    end
    for i=1:M
        for j=1:2:N
            Iw(i,j)=L(i,(j+1)/2)+floor((H(i,(j+1)/2)+1)/2);
            Iw(i,j+1)=L(i,(j+1)/2)-floor(H(i,(j+1)/2)/2);
        end
    end
else
    Iw=-1000;
end
end