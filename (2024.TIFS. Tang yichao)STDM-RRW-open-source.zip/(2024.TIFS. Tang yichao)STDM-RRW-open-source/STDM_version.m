function [ PSNR_lw1, psnr_Iw3, BER_no_attack  , BER_gaussian_robust, BER_jpeg_robust, BER_jpeg2000_robust,BER_rotate_robust, BER_resize_robust,  BER_medfilt_robust, BER_mean_robust]= STDM_version(I, MODE, seed_num, nMax, num, Delta,spread,Q)%, BER_resize_robust, BER_gaussian_robust, BER_jpeg_robust, BER_jpeg2000_robust
rng(seed_num,'twister');
%% 预备环节（实验所需参数初始化）
w =randi([0,1],1,num);
d0=0;
d1=d0 + (Delta/2);

%% 选择需要计算的PHT矩 （先测试PCET，这个代码暂时不用）
if MODE==1
    MMT=PCET_func(I,nMax);
elseif MODE==2
    MMT=PCT_func(I,nMax);
elseif MODE==3
    MMT=PST_func(I,nMax);
else
    disp('Error!');
    return;
end
%% 步骤2. 确认水印嵌入顺序
% 调换顺序，便于嵌入
temp(1,:) = abs(MMT(1,:)+1i*MMT(2,:)); %模从小到大
temp(2,:)=MMT(1,:); %阶数
temp(3,:)=MMT(2,:); %重复数
temp(4,:)=MMT(3,:); %矩的大小
[Mnm,ind]=sortrows(temp'); % ind从前到后的顺序代表了阶数和重复数递增的顺序
Mnm = Mnm'; ind = ind'; %E是调整顺序后的PHT矩



%% 步骤3. 确认嵌入的矩
moment = 0;
for k = 1 : length(Mnm)
    if MODE == 1
        if mod(Mnm(3,k), 4) ~= 0  ...
                && (Mnm(2,k)==0 && abs(Mnm(3,k))<=7)==0 && (Mnm(2,k)==1 && abs(Mnm(3,k))<=5)==0 && (Mnm(2,k)==2 && abs(Mnm(3,k))<=2)==0
            if Mnm(2,k) == 0 && Mnm(3,k) > 0
                moment = moment + 1;
                tem(moment)=k;
            elseif Mnm(2,k) > 0
                moment = moment + 1;
                tem(moment)=k;
            end
        end
    elseif MODE == 2
        if mod(Mnm(3,k), 4) ~= 0  ...
                && (Mnm(2,k)==0 && abs(Mnm(3,k))<=7)==0 && (Mnm(2,k)==1 && abs(Mnm(3,k))<=7)==0 ...
                && (Mnm(2,k)==2 && abs(Mnm(3,k))<=5)==0 && (Mnm(2,k)==3 && abs(Mnm(3,k))<=2)==0%Mnm(1,k)>=7%(abs(Mnm(2,k))+abs(Mnm(3,k)))>=9
            if  Mnm(2,k)>=0 && Mnm(3,k) > 0 
                moment = moment + 1;
                tem(moment)=k;
            end
        end
    elseif MODE == 3
        if mod(Mnm(3,k), 4) ~= 0  ...
                && (Mnm(2,k)==1 && abs(Mnm(3,k))<=7)==0 && (Mnm(2,k)==2 && abs(Mnm(3,k))<=5)==0 && (Mnm(2,k)==3 && abs(Mnm(3,k))<=2)==0%Mnm(1,k)>=7%(abs(Mnm(2,k))+abs(Mnm(3,k)))>=9
            if  Mnm(2,k)>=1 && Mnm(3,k) > 0  
                moment = moment + 1;
                tem(moment)=k;
            end
        end
    end
end
insert_palace = tem(1:num*spread);
moment = 0;
for k = 1 : length(Mnm)
    if ismember(k,insert_palace(1,:))
        moment = moment + 1;
        Origin_Mnm(moment)=Mnm(4,k);
    end
end

for i = 1 : length(insert_palace)/spread
    Q_tem= abs(Origin_Mnm(spread*(i-1)+1:spread*(i-1)+spread));
    Q1(spread*(i-1)+1:spread*(i-1)+spread)=Q_tem/norm(Q_tem);
end

load('fitting\TANG_test _all\PCET_Save_N.mat')
load('fitting\TANG_test _all\PCET_Save_M.mat')
load('fitting\TANG_test _all\PCET_gaussian_Mnm_diff_avg.mat')
load('fitting\TANG_test _all\PCET_jpeg2000_Mnm_diff_avg.mat')
load('fitting\TANG_test _all\PCET_mean5_Mnm_diff_avg.mat')
PCET_attack_diff=PCET_gaussian_Mnm_diff_avg+PCET_jpeg2000_Mnm_diff_avg+PCET_mean5_Mnm_diff_avg;

load('fitting\TANG_test _all\PCT_Save_N.mat')
load('fitting\TANG_test _all\PCT_Save_M.mat')
load('fitting\TANG_test _all\PCT_gaussian_Mnm_diff_avg.mat')
load('fitting\TANG_test _all\PCT_jpeg2000_Mnm_diff_avg.mat')
load('fitting\TANG_test _all\PCT_mean_Mnm_diff_avg.mat')
PCT_attack_diff=PCT_gaussian_Mnm_diff_avg+PCT_jpeg2000_Mnm_diff_avg+PCT_mean_Mnm_diff_avg;

load('fitting\TANG_test _all\PST_Save_N.mat')
load('fitting\TANG_test _all\PST_Save_M.mat')
load('fitting\TANG_test _all\PST_gaussian_Mnm_diff_avg.mat')
load('fitting\TANG_test _all\PST_jpeg2000_Mnm_diff_avg.mat')
load('fitting\TANG_test _all\PST_mean5_Mnm_diff_avg.mat')
PST_attack_diff=PST_gaussian_Mnm_diff_avg+PST_jpeg2000_Mnm_diff_avg+PST_mean5_Mnm_diff_avg;

[fitresult, ~] = createFits(PCET_Save_N, PCET_Save_M, PCET_attack_diff, PCT_Save_N, PCT_Save_M, PCT_attack_diff, PST_Save_N, PST_Save_M, PST_attack_diff);

moment=0;
for k = 1 : length(Mnm)
    if ismember(k,insert_palace(1,:))
        moment = moment + 1;
        tem_n(moment)=Mnm(2,k);
        tem_m(moment)=Mnm(3,k);
    end
end

for i = 1 : length(insert_palace)/spread
    Alpha_tem(spread*(i-1)+1:spread*(i-1)+spread)=fitresult{MODE}(tem_n(spread*(i-1)+1:spread*(i-1)+spread),tem_m(spread*(i-1)+1:spread*(i-1)+spread));
end
Alpha_tem=Alpha_tem/mean(Alpha_tem);
Beta=Alpha_tem;
edge_1=0.8;edge_2=1.2;
for i = 1 : length(insert_palace)
    Beta(i)=((max(Alpha_tem)*edge_1-min(Alpha_tem)*edge_2+Alpha_tem(i)*(edge_2-edge_1))/(max(Alpha_tem)-min(Alpha_tem)));%/1000;
end
Beta=Beta/mean(Beta); %'Beta' is the 'Tni,li' in the paper
%% Watermark embedding

[PSNR_lw1, Iw1, reversible_watermarking, w_overflow]=adaptive_watermark_embedding(MODE, I,nMax, w,Q, Q1,Delta,Beta,Origin_Mnm,Mnm,num,insert_palace, d0,d1, seed_num, spread);


%% Watermark extraction
if MODE==1
    MMT_1=PCET_func(uint8(Iw1),nMax);
elseif MODE==2
    MMT_1=PCT_func(uint8(Iw1),nMax);
elseif MODE==3
    MMT_1=PST_func(uint8(Iw1),nMax);
end
% 调换顺序，便于嵌入
temp_w(1,:) = abs(MMT_1(1,:)+1i*MMT_1(2,:)); %模从小到大
temp_w(2,:)=MMT_1(1,:); %阶数
temp_w(3,:)=MMT_1(2,:); %重复数
temp_w(4,:)=MMT_1(3,:); %矩的大小
[Mnm_w1,~]=sortrows(temp_w'); % ind从前到后的顺序代表了阶数和重复数递增的顺序
Mnm_w1 = Mnm_w1'; %调整顺序后的PHT矩

%% 
moment = 0;
for k = 1 : length(Mnm_w1)
    if ismember(k,insert_palace(1,:))
        moment = moment + 1;
        Watermarked_Mnm_r(moment)=Mnm_w1(4,k); %未标准化的几何矩
    end
end
for i = 1 : length(insert_palace)/spread
    Q_tem= abs(Watermarked_Mnm_r(spread*(i-1)+1:spread*(i-1)+spread));
    Q1(spread*(i-1)+1:spread*(i-1)+spread)=Q_tem/norm(Q_tem);
end
for i = 1 : length(insert_palace)/spread
        Normalized_Mnm_r(spread*(i-1)+1:spread*(i-1)+spread) = 10000*abs(Watermarked_Mnm_r(spread*(i-1)+1:spread*(i-1)+spread))./...
        (Mnm_w1(4,1)*Beta(spread*(i-1)+1:spread*(i-1)+spread));
    inner_r(i)=dot(Normalized_Mnm_r(spread*(i-1)+1:spread*(i-1)+spread),Q1(spread*(i-1)+1:spread*(i-1)+spread)); % xTu; MRTu
    Quantizer_r_0(i)=Delta  * round( (inner_r(i) - d0) / Delta ) + d0; % Q0
    Quantizer_r_1(i)=Delta  * round( (inner_r(i) - d1) / Delta ) + d1; % Q1
    if abs(Quantizer_r_0(i)-inner_r(i))<=abs(Quantizer_r_1(i)-inner_r(i))  % Qq0
        w_ex(i)=0;
    else
        w_ex(i)=1;
    end
end

w_be=w;

%% Check the extraction
isequal(w_ex,w_be)
te=sum(abs(w_be-w_ex));
BER_no_attack = te/length(w_ex);

%% Auxiliary information embedding
[Iw3, ~, ~, ~, ~, ~, ~, ~, ~] = reversible_embedding(Iw1, reversible_watermarking) ;
psnr_Iw3 = psnr(uint8(I),uint8(Iw3)); %计算可逆水印嵌入后的PSNR  
imwrite(uint8(Iw3),'Iw3.bmp'); %final watermarked image
% imshow(uint8(Iw3))

%% Auxiliary information extraction

[Iw_1,err_info] = reversible_decodding(Iw3,numel(reversible_watermarking)); 

check_img=isequal(Iw_1,Iw1); %Verify that the image extraction is successful 
%Iw1 is the robust watermarked image
check_err= isequal(err_info,reversible_watermarking); %Verify the watermark extraction is successful



%% Image recovering
    t=5;%
    bl= 20;%
    j=0;
    for k = 1 : length(Mnm)
        if ismember(k,insert_palace)
            j = j + 1;
            w_r{1,j}=reversible_watermarking(bl*(j-1)*2+1:bl*(j-1)*2+bl);%Real binary
            w_r{2,j}=reversible_watermarking(bl*(j-1)*2+bl+1:bl*j*2);%Imaginary binary
            w_re(1,j)=bin_to_signed(w_r{1,j},bl)/10^t;%Real binary to decimal
            w_re(2,j)=bin_to_signed(w_r{2,j},bl)/10^t;%Imaginary binary to decimal
            Mrew(j)=w_re(1,j)+w_re(2,j)*1i;%
            
            [~,col]=find(Mnm(2,:)==-Mnm(2,k) & Mnm(3,:)==-Mnm(3,k));
            M2(1,k)=Mnm(1,k);M2(2,k)=Mnm(2,k);M2(3,k)=Mnm(3,k);
            M2(4,k)=Mrew(j);
            M2(1,col)=Mnm(1,col);M2(2,col)=Mnm(2,col);M2(3,col)=Mnm(3,col);
            M2(4,col)=conj(Mrew(j)); % 
        end
    end
    Irw2=PCET_reconstruct_func(size(I,1),M2); %The error image

    Irw2(isnan(Irw2))=0; %
    Irw2=round(Irw2);
    Iw2 = round(double(Iw_1) - Irw2);%

    if(isempty(w_overflow)==0)
        w_overflow=reversible_watermarking(bl*2*num*2+1:length(reversible_watermarking));%
        for k = 1 : (length(reversible_watermarking)-bl*2*num*2)/28
            w_overflow1=w_overflow((k-1)*28+1:k*28);
            a1=bin_to_unsigned(w_overflow1(1:18),18);%
            Iw2(mod(a1,512),ceil(a1/512))=Iw2(mod(a1,512),ceil(a1/512))+bin_to_signed(w_overflow1(19:28),10);
        end
    end
    
    imwrite(uint8(Iw2),'Iw2.bmp'); % the recovered image
    psnr_Iw2 = psnr(uint8(I),uint8(Iw2)); %
    isequal(uint8(I),uint8(Iw2))
%     imshow(uint8(Iw2)); % Iw2 is the recovered image

    
%% Robustness test（rotation）
for l = 1 : 9%5 %7%
    rng(seed_num,'twister');
    K_tem_rotate_robust = imrotate(uint8(Iw1),l*20,'crop');%10+(l-1)*20
    if MODE==1
        MMT_rotate_robust=PCET_func(K_tem_rotate_robust,nMax);
    elseif MODE==2
        MMT_rotate_robust=PCT_func(K_tem_rotate_robust,nMax);
    elseif MODE==3
        MMT_rotate_robust=PST_func(K_tem_rotate_robust,nMax);
    end
    % 调换顺序，便于嵌入
    temp_w2_rotate_robust(1,:) = abs(MMT_rotate_robust(1,:)+1i*MMT_rotate_robust(2,:)); %模从小到大
    temp_w2_rotate_robust(2,:)=MMT_rotate_robust(1,:); %阶数
    temp_w2_rotate_robust(3,:)=MMT_rotate_robust(2,:); %重复数
    temp_w2_rotate_robust(4,:)=MMT_rotate_robust(3,:); %矩的大小
    [Mnm_w1_rotate_robust,ind_w2_rotate_robust]=sortrows(temp_w2_rotate_robust'); % ind从前到后的顺序代表了阶数和重复数递增的顺序
    Mnm_w1_rotate_robust = Mnm_w1_rotate_robust'; ind_w2_rotate_robust = ind_w2_rotate_robust'; %E是调整顺序后的PHT矩
    moment = 0;
    for k = 1 : length(Mnm_w1_rotate_robust)
        if ismember(k,insert_palace(1,:))% && k<=insert_palace_max
            moment = moment + 1;
            Watermarked_Mnm_w1_rotate_robust(moment)=Mnm_w1_rotate_robust(4,k);
        end
    end
    %原提取
    for i = 1 : length(insert_palace)/spread
        Q_tem= abs(Watermarked_Mnm_w1_rotate_robust(spread*(i-1)+1:spread*(i-1)+spread));
        Q1(spread*(i-1)+1:spread*(i-1)+spread)=Q_tem/norm(Q_tem);
    end
    for i = 1 : length(insert_palace)/spread
        Normalized_Watermarked_Mnm_w1_rotate(spread*(i-1)+1:spread*(i-1)+spread) = 10000*abs(Watermarked_Mnm_w1_rotate_robust(spread*(i-1)+1:spread*(i-1)+spread))./...
        (Mnm_w1_rotate_robust(4,1)*Beta(spread*(i-1)+1:spread*(i-1)+spread));
        rotate_inner_r(i)=dot(Normalized_Watermarked_Mnm_w1_rotate(spread*(i-1)+1:spread*(i-1)+spread),Q1(spread*(i-1)+1:spread*(i-1)+spread)); % xTu; MRTu
        rotate_Embed_0(i)=Delta  * round( (rotate_inner_r(i) - d0) / Delta ) + d0; % Q0
        rotate_Embed_1(i)=Delta  * round( (rotate_inner_r(i) - d1) / Delta ) + d1; % Q1
        if abs(rotate_Embed_0(i)-rotate_inner_r(i))<=abs(rotate_Embed_1(i)-rotate_inner_r(i))  % Qq0
            w_ex_rotate_robust(i)=0;
        else
            w_ex_rotate_robust(i)=1;
        end
    end
    w_be_rotate_robust=w; %check
    te_rotate_robust(l)=sum(abs(w_be_rotate_robust-w_ex_rotate_robust));
    BER_rotate_robust(l) = te_rotate_robust(l)/length(w_ex_rotate_robust);
end

%% 鲁棒性测试（抗缩放攻击）
for l = 1 : 16%3%6%
    rng(seed_num,'twister');
    resize_length=round(length(Iw1)*(0.4+l*0.1));
    if mod(resize_length,2)~=0
        resize_length=resize_length+1;
    end
    K_tem_resize_robust =imresize(uint8(Iw1),[resize_length,resize_length]);%imresize(uint8(Iw2),0.2+l*0.3);%
    if MODE==1
        MMT_resize_robust=PCET_func(K_tem_resize_robust,nMax);
    elseif MODE==2
        MMT_resize_robust=PCT_func(K_tem_resize_robust,nMax);
    elseif MODE==3
        MMT_resize_robust=PST_func(K_tem_resize_robust,nMax);
    end
    % 调换顺序，便于嵌入
    temp_w2_resize_robust(1,:) = abs(MMT_resize_robust(1,:)+1i*MMT_resize_robust(2,:)); %模从小到大
    temp_w2_resize_robust(2,:)=MMT_resize_robust(1,:); %阶数
    temp_w2_resize_robust(3,:)=MMT_resize_robust(2,:); %重复数
    temp_w2_resize_robust(4,:)=MMT_resize_robust(3,:); %矩的大小
    [Mnm_w1_resize_robust,ind_w2_resize_robust]=sortrows(temp_w2_resize_robust'); % ind从前到后的顺序代表了阶数和重复数递增的顺序
    Mnm_w1_resize_robust = Mnm_w1_resize_robust'; ind_w2_resize_robust = ind_w2_resize_robust'; %E是调整顺序后的PHT矩
    moment = 0;
    for k = 1 : length(Mnm_w1_resize_robust)
        if ismember(k,insert_palace(1,:))% && k<=insert_palace_max
            moment = moment + 1;
            Watermarked_Mnm_w1_resize_robust(moment)=Mnm_w1_resize_robust(4,k);
        end
    end
    %原提取
    for i = 1 : length(insert_palace)/spread
        Q_tem= abs(Watermarked_Mnm_w1_resize_robust(spread*(i-1)+1:spread*(i-1)+spread));
        Q1(spread*(i-1)+1:spread*(i-1)+spread)=Q_tem/norm(Q_tem);
    end
    for i = 1 : length(insert_palace)/spread
        Normalized_Watermarked_Mnm_w1_resize(spread*(i-1)+1:spread*(i-1)+spread) = 10000*abs(Watermarked_Mnm_w1_resize_robust(spread*(i-1)+1:spread*(i-1)+spread))./...
        (Mnm_w1_resize_robust(4,1)*Beta(spread*(i-1)+1:spread*(i-1)+spread));
        resize_inner_r(i)=dot(Normalized_Watermarked_Mnm_w1_resize(spread*(i-1)+1:spread*(i-1)+spread),Q1(spread*(i-1)+1:spread*(i-1)+spread)); % xTu; MRTu
        resize_Embed_0(i)=Delta  * round( (resize_inner_r(i) - d0) / Delta ) + d0; % Q0
        resize_Embed_1(i)=Delta  * round( (resize_inner_r(i) - d1) / Delta ) + d1; % Q1
        if abs(resize_Embed_0(i)-resize_inner_r(i))<=abs(resize_Embed_1(i)-resize_inner_r(i))  % Qq0
            w_ex_resize_robust(i)=0;
        else
            w_ex_resize_robust(i)=1;
        end
    end
    w_be_resize_robust=w; %判断提取是否成功
    te_resize_robust(l)=sum(abs(w_be_resize_robust-w_ex_resize_robust));
    BER_resize_robust(l) = te_resize_robust(l)/length(w_ex_resize_robust);
end
%% 鲁棒性测试（抗高斯噪声攻击）
for l = 1:13 %7%5% 一个个测试和一起测试得到的结果竟然是不同的，而且不同起始和终止也会导致不同的误码率
        rng(seed_num,'twister');
    K_tem_gaussian_robust = imnoise(uint8(Iw1), 'gaussian', 0, 0.005+(l-1)*0.002);%方差为0.03的高斯噪声 %
    if MODE==1
        MMT_gaussian_robust=PCET_func(K_tem_gaussian_robust,nMax);
    elseif MODE==2
        MMT_gaussian_robust=PCT_func(K_tem_gaussian_robust,nMax);
    elseif MODE==3
        MMT_gaussian_robust=PST_func(K_tem_gaussian_robust,nMax);
    end
    % 调换顺序，便于嵌入
    temp_w2_gaussian_robust(1,:) = abs(MMT_gaussian_robust(1,:)+1i*MMT_gaussian_robust(2,:)); %模从小到大
    temp_w2_gaussian_robust(2,:)=MMT_gaussian_robust(1,:); %阶数
    temp_w2_gaussian_robust(3,:)=MMT_gaussian_robust(2,:); %重复数
    temp_w2_gaussian_robust(4,:)=MMT_gaussian_robust(3,:); %矩的大小
    [Mnm_w1_gaussian_robust,ind_w2_gaussian_robust]=sortrows(temp_w2_gaussian_robust'); % ind从前到后的顺序代表了阶数和重复数递增的顺序
    Mnm_w1_gaussian_robust = Mnm_w1_gaussian_robust'; ind_w2_gaussian_robust = ind_w2_gaussian_robust'; %E是调整顺序后的PHT矩
    moment = 0;
    for k = 1 : length(Mnm_w1_gaussian_robust)
        if ismember(k,insert_palace(1,:))% && k<=insert_palace_max
            moment = moment + 1;
            Watermarked_Mnm_w1_gaussian_robust(moment)=Mnm_w1_gaussian_robust(4,k);
        end
    end
    for i = 1 : length(insert_palace)/spread
        Q_tem= abs(Watermarked_Mnm_w1_gaussian_robust(spread*(i-1)+1:spread*(i-1)+spread));
        Q1(spread*(i-1)+1:spread*(i-1)+spread)=Q_tem/norm(Q_tem);
    end
    for i = 1 : length(insert_palace)/spread
        Normalized_Watermarked_Mnm_w1_gaussian(spread*(i-1)+1:spread*(i-1)+spread) = 10000*abs(Watermarked_Mnm_w1_gaussian_robust(spread*(i-1)+1:spread*(i-1)+spread))./...
        (Mnm_w1_gaussian_robust(4,1)*Beta(spread*(i-1)+1:spread*(i-1)+spread));
        gaussian_inner_r(i)=dot(Normalized_Watermarked_Mnm_w1_gaussian(spread*(i-1)+1:spread*(i-1)+spread),Q1(spread*(i-1)+1:spread*(i-1)+spread)); % xTu; MRTu
        gaussian_Embed_0(i)=Delta  * round( (gaussian_inner_r(i) - d0) / Delta ) + d0; % Q0
        gaussian_Embed_1(i)=Delta  * round( (gaussian_inner_r(i) - d1) / Delta ) + d1; % Q1
        if abs(gaussian_Embed_0(i)-gaussian_inner_r(i))<=abs(gaussian_Embed_1(i)-gaussian_inner_r(i))  % Qq0
            w_ex_gaussian_robust(i)=0;
        else
            w_ex_gaussian_robust(i)=1;
        end
    end
    w_be_gaussian_robust=w; %判断提取是否成功
    
    te_gaussian_robust(l)=sum(abs(w_be_gaussian_robust-w_ex_gaussian_robust));
    BER_gaussian_robust(l) = te_gaussian_robust(l)/length(w_ex_gaussian_robust);
end
%% 鲁棒性测试（抗JPEG攻击）
for l = 1: 10%3% 5%
    rng(seed_num,'twister');
    imwrite(uint8(Iw1),'Iw_jpeg_compress.jpg','Quality',10*l);
    K_tem_jpeg_robust = imread('Iw_jpeg_compress.jpg');
    if MODE==1
        MMT_jpeg_robust=PCET_func(K_tem_jpeg_robust,nMax);
    elseif MODE==2
        MMT_jpeg_robust=PCT_func(K_tem_jpeg_robust,nMax);
    elseif MODE==3
        MMT_jpeg_robust=PST_func(K_tem_jpeg_robust,nMax);
    end
    % 调换顺序，便于嵌入
    temp_w2_jpeg_robust(1,:) = abs(MMT_jpeg_robust(1,:)+1i*MMT_jpeg_robust(2,:)); %模从小到大
    temp_w2_jpeg_robust(2,:)=MMT_jpeg_robust(1,:); %阶数
    temp_w2_jpeg_robust(3,:)=MMT_jpeg_robust(2,:); %重复数
    temp_w2_jpeg_robust(4,:)=MMT_jpeg_robust(3,:); %矩的大小
    [Mnm_w1_jpeg_robust,ind_w2_jpeg_robust]=sortrows(temp_w2_jpeg_robust'); % ind从前到后的顺序代表了阶数和重复数递增的顺序
    Mnm_w1_jpeg_robust = Mnm_w1_jpeg_robust'; ind_w2_jpeg_robust = ind_w2_jpeg_robust'; %E是调整顺序后的PHT矩
    moment = 0;
    for k = 1 : length(Mnm_w1_jpeg_robust)
        if ismember(k,insert_palace(1,:))% && k<=insert_palace_max
            moment = moment + 1;
            Watermarked_Mnm_w1_jpeg_robust(moment)=Mnm_w1_jpeg_robust(4,k);
        end
    end
    %原提取
    for i = 1 : length(insert_palace)/spread
        Q_tem= abs(Watermarked_Mnm_w1_jpeg_robust(spread*(i-1)+1:spread*(i-1)+spread));
        Q1(spread*(i-1)+1:spread*(i-1)+spread)=Q_tem/norm(Q_tem);
    end
    for i = 1 : length(insert_palace)/spread
        Normalized_Watermarked_Mnm_w1_jpeg(spread*(i-1)+1:spread*(i-1)+spread) = 10000*abs(Watermarked_Mnm_w1_jpeg_robust(spread*(i-1)+1:spread*(i-1)+spread))./...
        (Mnm_w1_jpeg_robust(4,1)*Beta(spread*(i-1)+1:spread*(i-1)+spread));
        jpeg_inner_r(i)=dot(Normalized_Watermarked_Mnm_w1_jpeg(spread*(i-1)+1:spread*(i-1)+spread),Q1(spread*(i-1)+1:spread*(i-1)+spread)); % xTu; MRTu
        jpeg_Embed_0(i)=Delta  * round( (jpeg_inner_r(i) - d0) / Delta ) + d0; % Q0
        jpeg_Embed_1(i)=Delta  * round( (jpeg_inner_r(i) - d1) / Delta ) + d1; % Q1
        if abs(jpeg_Embed_0(i)-jpeg_inner_r(i))<=abs(jpeg_Embed_1(i)-jpeg_inner_r(i))  % Qq0
            w_ex_jpeg_robust(i)=0;
        else
            w_ex_jpeg_robust(i)=1;
        end
    end
    
    w_be_jpeg_robust=w; %判断提取是否成功
    
    te_jpeg_robust(l)=sum(abs(w_be_jpeg_robust-w_ex_jpeg_robust));
    BER_jpeg_robust(l) = te_jpeg_robust(l)/length(w_ex_jpeg_robust);
end
%% 鲁棒性测试（抗JPEG2000攻击）
for l = 1:10%1:10 %1:3%
        rng(seed_num,'twister');
%         imwrite(uint8(Iw1),'Iw_jpeg2000_compress.jp2','CompressionRatio',60+(l-1)*20);
    imwrite(uint8(Iw1),'Iw_jpeg2000_compress.jp2','CompressionRatio',10*l);
    K_tem_jpeg2000_robust = imread('Iw_jpeg2000_compress.jp2');
    if MODE==1
        MMT_jpeg2000_robust=PCET_func(K_tem_jpeg2000_robust,nMax);
    elseif MODE==2
        MMT_jpeg2000_robust=PCT_func(K_tem_jpeg2000_robust,nMax);
    elseif MODE==3
        MMT_jpeg2000_robust=PST_func(K_tem_jpeg2000_robust,nMax);
    end
    % 调换顺序，便于嵌入
    temp_w2_jpeg2000_robust(1,:) = abs(MMT_jpeg2000_robust(1,:)+1i*MMT_jpeg2000_robust(2,:)); %模从小到大
    temp_w2_jpeg2000_robust(2,:)=MMT_jpeg2000_robust(1,:); %阶数
    temp_w2_jpeg2000_robust(3,:)=MMT_jpeg2000_robust(2,:); %重复数
    temp_w2_jpeg2000_robust(4,:)=MMT_jpeg2000_robust(3,:); %矩的大小
    [Mnm_w1_jpeg2000_robust,ind_w2_jpeg2000_robust]=sortrows(temp_w2_jpeg2000_robust'); % ind从前到后的顺序代表了阶数和重复数递增的顺序
    Mnm_w1_jpeg2000_robust = Mnm_w1_jpeg2000_robust'; ind_w2_jpeg2000_robust = ind_w2_jpeg2000_robust'; %E是调整顺序后的PHT矩
    moment = 0;
    for k = 1 : length(Mnm_w1_jpeg2000_robust)
        if ismember(k,insert_palace(1,:))% && k<=insert_palace_max
            moment = moment + 1;
            Watermarked_Mnm_w1_jpeg2000_robust(moment)=Mnm_w1_jpeg2000_robust(4,k);
        end
    end
    % % 原提取
    for i = 1 : length(insert_palace)/spread
        Q_tem= abs(Watermarked_Mnm_w1_jpeg2000_robust(spread*(i-1)+1:spread*(i-1)+spread));
        Q1(spread*(i-1)+1:spread*(i-1)+spread)=Q_tem/norm(Q_tem);
    end
    for i = 1 : length(insert_palace)/spread
        Normalized_Watermarked_Mnm_w1_jpeg2000(spread*(i-1)+1:spread*(i-1)+spread) = 10000*abs(Watermarked_Mnm_w1_jpeg2000_robust(spread*(i-1)+1:spread*(i-1)+spread))./...
        (Mnm_w1_jpeg2000_robust(4,1)*Beta(spread*(i-1)+1:spread*(i-1)+spread));
%         Normalized_jpeg2000_Mnm(spread*(i-1)+1:spread*(i-1)+spread) = abs(Mnm_jpeg2000_w_robust(spread*(i-1)+1:spread*(i-1)+spread))./Beta(spread*(i-1)+1:spread*(i-1)+spread);
        jpeg2000_inner_r(i)=dot(Normalized_Watermarked_Mnm_w1_jpeg2000(spread*(i-1)+1:spread*(i-1)+spread),Q1(spread*(i-1)+1:spread*(i-1)+spread)); % xTu; MRTu
        jpeg2000_Embed_0(i)=Delta  * round( (jpeg2000_inner_r(i) - d0) / Delta ) + d0; % Q0
        jpeg2000_Embed_1(i)=Delta  * round( (jpeg2000_inner_r(i) - d1) / Delta ) + d1; % Q1
        if abs(jpeg2000_Embed_0(i)-jpeg2000_inner_r(i))<=abs(jpeg2000_Embed_1(i)-jpeg2000_inner_r(i))  % Qq0
            w_ex_jpeg2000_robust(i)=0;
        else
            w_ex_jpeg2000_robust(i)=1;
        end
    end
    
    w_be_jpeg2000_robust=w; %判断提取是否成功
    
    te_jpeg2000_robust(l)=sum(abs(w_be_jpeg2000_robust-w_ex_jpeg2000_robust));
    BER_jpeg2000_robust(l) = te_jpeg2000_robust(l)/length(w_ex_jpeg2000_robust);
end

%% 测试均值/中值/椒盐噪声
for l = 1 : 3 %7%
    rng(seed_num,'twister');
    w2=fspecial('average',[2*l+1,2*l+1]);
    K_tem_mean_robust=imfilter(uint8(Iw1),w2,'replicate'); 
    if MODE==1
        MMT_mean_robust=PCET_func(K_tem_mean_robust,nMax);
    elseif MODE==2
        MMT_mean_robust=PCT_func(K_tem_mean_robust,nMax);
    elseif MODE==3
        MMT_mean_robust=PST_func(K_tem_mean_robust,nMax);
    end
    % 调换顺序，便于嵌入
    temp_w2_mean_robust(1,:) = abs(MMT_mean_robust(1,:)+1i*MMT_mean_robust(2,:)); %模从小到大
    temp_w2_mean_robust(2,:)=MMT_mean_robust(1,:); %阶数
    temp_w2_mean_robust(3,:)=MMT_mean_robust(2,:); %重复数
    temp_w2_mean_robust(4,:)=MMT_mean_robust(3,:); %矩的大小
    [Mnm_w1_mean_robust,ind_w2_mean_robust]=sortrows(temp_w2_mean_robust'); % ind从前到后的顺序代表了阶数和重复数递增的顺序
    Mnm_w1_mean_robust = Mnm_w1_mean_robust'; ind_w2_mean_robust = ind_w2_mean_robust'; %E是调整顺序后的PHT矩
    moment = 0;
    for k = 1 : length(Mnm_w1_mean_robust)
        if ismember(k,insert_palace(1,:))% && k<=insert_palace_max
            %             [~,tem_col]=find(insert_palace(1,:)==k);
            moment = moment + 1;
            Watermarked_Mnm_w1_mean_robust(moment)=Mnm_w1_mean_robust(4,k);
        end
    end
    % % 原提取
    for i = 1 : length(insert_palace)/spread
        Q_tem= abs(Watermarked_Mnm_w1_mean_robust(spread*(i-1)+1:spread*(i-1)+spread));
        Q1(spread*(i-1)+1:spread*(i-1)+spread)=Q_tem/norm(Q_tem);
    end
    for i = 1 : length(insert_palace)/spread
        Normalized_Watermarked_Mnm_w1_mean(spread*(i-1)+1:spread*(i-1)+spread) = 10000*abs(Watermarked_Mnm_w1_mean_robust(spread*(i-1)+1:spread*(i-1)+spread))./...
        (Mnm_w1_mean_robust(4,1)*Beta(spread*(i-1)+1:spread*(i-1)+spread));
        mean_inner_r(i)=dot(Normalized_Watermarked_Mnm_w1_mean(spread*(i-1)+1:spread*(i-1)+spread),Q1(spread*(i-1)+1:spread*(i-1)+spread)); % xTu; MRTu
        mean_Embed_0(i)=Delta  * round( (mean_inner_r(i) - d0) / Delta ) + d0; % Q0
        mean_Embed_1(i)=Delta  * round( (mean_inner_r(i) - d1) / Delta ) + d1; % Q1
        if abs(mean_Embed_0(i)-mean_inner_r(i))<=abs(mean_Embed_1(i)-mean_inner_r(i))  % Qq0
            w_ex_mean_robust(i)=0;
        else
            w_ex_mean_robust(i)=1;
        end
    end
    w_be_mean_robust=w; %判断提取是否成功
    
    te_mean_robust(l)=sum(abs(w_be_mean_robust-w_ex_mean_robust));
    BER_mean_robust(l) = te_mean_robust(l)/length(w_ex_mean_robust);
    
end


for l = 1 : 3 %7%
    rng(seed_num,'twister');
    K_tem_medfilt_robust=medfilt2(uint8(Iw1),[2*l+1,2*l+1]);
    if MODE==1
        MMT_medfilt_robust=PCET_func(K_tem_medfilt_robust,nMax);
    elseif MODE==2
        MMT_medfilt_robust=PCT_func(K_tem_medfilt_robust,nMax);
    elseif MODE==3
        MMT_medfilt_robust=PST_func(K_tem_medfilt_robust,nMax);
    end
    % 调换顺序，便于嵌入
    temp_w2_medfilt_robust(1,:) = abs(MMT_medfilt_robust(1,:)+1i*MMT_medfilt_robust(2,:)); %模从小到大
    temp_w2_medfilt_robust(2,:)=MMT_medfilt_robust(1,:); %阶数
    temp_w2_medfilt_robust(3,:)=MMT_medfilt_robust(2,:); %重复数
    temp_w2_medfilt_robust(4,:)=MMT_medfilt_robust(3,:); %矩的大小
    [Mnm_w1_medfilt_robust,ind_w2_medfilt_robust]=sortrows(temp_w2_medfilt_robust'); % ind从前到后的顺序代表了阶数和重复数递增的顺序
    Mnm_w1_medfilt_robust = Mnm_w1_medfilt_robust'; ind_w2_medfilt_robust = ind_w2_medfilt_robust'; %E是调整顺序后的PHT矩
    moment = 0;
    for k = 1 : length(Mnm_w1_medfilt_robust)
        if ismember(k,insert_palace(1,:))% && k<=insert_palace_max
            %             [~,tem_col]=find(insert_palace(1,:)==k);
            moment = moment + 1;
            Watermarked_Mnm_w1_medfilt_robust(moment)=Mnm_w1_medfilt_robust(4,k);
        end
    end
    % % 原提取
    for i = 1 : length(insert_palace)/spread
        Q_tem= abs(Watermarked_Mnm_w1_medfilt_robust(spread*(i-1)+1:spread*(i-1)+spread));
        Q1(spread*(i-1)+1:spread*(i-1)+spread)=Q_tem/norm(Q_tem);
    end
    for i = 1 : length(insert_palace)/spread
        Normalized_Watermarked_Mnm_w1_medfilt(spread*(i-1)+1:spread*(i-1)+spread) = 10000*abs(Watermarked_Mnm_w1_medfilt_robust(spread*(i-1)+1:spread*(i-1)+spread))./...
        (Mnm_w1_medfilt_robust(4,1)*Beta(spread*(i-1)+1:spread*(i-1)+spread));
%         Normalized_medfilt_Mnm(spread*(i-1)+1:spread*(i-1)+spread) = abs(Mnm_medfilt_w_robust(spread*(i-1)+1:spread*(i-1)+spread))./Beta(spread*(i-1)+1:spread*(i-1)+spread);
        medfilt_inner_r(i)=dot(Normalized_Watermarked_Mnm_w1_medfilt(spread*(i-1)+1:spread*(i-1)+spread),Q1(spread*(i-1)+1:spread*(i-1)+spread)); % xTu; MRTu
        medfilt_Embed_0(i)=Delta  * round( (medfilt_inner_r(i) - d0) / Delta ) + d0; % Q0
        medfilt_Embed_1(i)=Delta  * round( (medfilt_inner_r(i) - d1) / Delta ) + d1; % Q1
        if abs(medfilt_Embed_0(i)-medfilt_inner_r(i))<=abs(medfilt_Embed_1(i)-medfilt_inner_r(i))  % Qq0
            w_ex_medfilt_robust(i)=0;
        else
            w_ex_medfilt_robust(i)=1;
        end
    end
    w_be_medfilt_robust=w; %判断提取是否成功
    
    te_medfilt_robust(l)=sum(abs(w_be_medfilt_robust-w_ex_medfilt_robust));
    BER_medfilt_robust(l) = te_medfilt_robust(l)/length(w_ex_medfilt_robust);
end

%% 椒盐噪声
% for l = 1 : 5 %7%
%     rng(seed_num,'twister');
%     K_tem_salt_robust = imnoise(uint8(Iw1), 'salt & pepper',0.013+(l-1)*0.004);
%     % imshow(uint8(K_salt_robust));
%     if MODE==1
%         MMT_salt_robust=PCET_func(K_tem_salt_robust,nMax);
%     elseif MODE==2
%         MMT_salt_robust=PCT_func(K_tem_salt_robust,nMax);
%     elseif MODE==3
%         MMT_salt_robust=PST_func(K_tem_salt_robust,nMax);
%     end
%     % 调换顺序，便于嵌入
%     temp_w2_salt_robust(1,:) = abs(MMT_salt_robust(1,:)+1i*MMT_salt_robust(2,:)); %模从小到大
%     temp_w2_salt_robust(2,:)=MMT_salt_robust(1,:); %阶数
%     temp_w2_salt_robust(3,:)=MMT_salt_robust(2,:); %重复数
%     temp_w2_salt_robust(4,:)=MMT_salt_robust(3,:); %矩的大小
%     [Mnm_w1_salt_robust,ind_w2_salt_robust]=sortrows(temp_w2_salt_robust'); % ind从前到后的顺序代表了阶数和重复数递增的顺序
%     Mnm_w1_salt_robust = Mnm_w1_salt_robust'; ind_w2_salt_robust = ind_w2_salt_robust'; %E是调整顺序后的PHT矩
%     moment = 0;
%     for k = 1 : length(Mnm_w1_salt_robust)
%         if ismember(k,insert_palace(1,:))% && k<=insert_palace_max
%             %             [~,tem_col]=find(insert_palace(1,:)==k);
%             moment = moment + 1;
%             Watermarked_Mnm_w1_salt_robust(moment)=Mnm_w1_salt_robust(4,k);
%         end
%     end
%     % % 原提取
%     for i = 1 : length(insert_palace)/spread
%         Q_tem= abs(Watermarked_Mnm_w1_salt_robust(spread*(i-1)+1:spread*(i-1)+spread));
%         Q1(spread*(i-1)+1:spread*(i-1)+spread)=Q_tem/norm(Q_tem);
%     end
%     for i = 1 : length(insert_palace)/spread
%         Normalized_Watermarked_Mnm_w1_salt(spread*(i-1)+1:spread*(i-1)+spread) = 10000*abs(Watermarked_Mnm_w1_salt_robust(spread*(i-1)+1:spread*(i-1)+spread))./...
%         (Mnm_w1_salt_robust(4,1)*Beta(spread*(i-1)+1:spread*(i-1)+spread));
% %         Normalized_salt_Mnm(spread*(i-1)+1:spread*(i-1)+spread) = abs(Mnm_salt_w_robust(spread*(i-1)+1:spread*(i-1)+spread))./Beta(spread*(i-1)+1:spread*(i-1)+spread);
%         salt_inner_r(i)=dot(Normalized_Watermarked_Mnm_w1_salt(spread*(i-1)+1:spread*(i-1)+spread),Q1(spread*(i-1)+1:spread*(i-1)+spread)); % xTu; MRTu
%         salt_Embed_0(i)=Delta  * round( (salt_inner_r(i) - d0) / Delta ) + d0; % Q0
%         salt_Embed_1(i)=Delta  * round( (salt_inner_r(i) - d1) / Delta ) + d1; % Q1
%         if abs(salt_Embed_0(i)-salt_inner_r(i))<=abs(salt_Embed_1(i)-salt_inner_r(i))  % Qq0
%             w_ex_salt_robust(i)=0;
%         else
%             w_ex_salt_robust(i)=1;
%         end
%     end
%     w_be_salt_robust=w; %判断提取是否成功
%     
%     te_salt_robust(l)=sum(abs(w_be_salt_robust-w_ex_salt_robust));
%     BER_salt_robust(l) = te_salt_robust(l)/length(w_ex_salt_robust);
% end
% % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% 
