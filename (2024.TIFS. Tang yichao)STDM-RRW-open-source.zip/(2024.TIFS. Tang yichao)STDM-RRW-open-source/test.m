comb=4;
dim=6;
succ=true;
y=2;
while true
    x=eye(dim);
    for i = 1 : dim
        num=1;
        get=ones;
        for k = 1 : dim
            num = 1;
            for j = 1 : i
                if (j~=k && x(j,k) == 1)
                    num = num + 1;
                end
            end
            if (k~=i && num < 2)
                get=[get,k];
            end
        end
        rowrank = randperm(size(get, 2)); % 随机打乱的数字，从1~行数打乱
        get = get(rowrank);
        if (length(get) < y)
            succ = false;
            break
        end
        for k = 1 : y
            x(i,get(k)) = 1;
        end
        succ = true;
    end
    if succ
        break
    end
end


% for i = 1 : dim
%     num = 0;
%     tem_rand=randperm(num-i);
%     for j = 1 : dim
%         num = 0;
        


a = double(py.code_mmk.calc())

py.code_mmk.py


py.code2.my_function()
a=py.code3.my_function(int8(5),int8(3))
cell{a};
	class(a)
% rand_matrix=zeros(num);
% %每行直接生成5个数，并赋值；
% %赋值完成后判断这五列非零数是否大于5，若是则重新赋值，若否则开始下一列赋值。
% for i = 1 : num
%     rand_matrix(i,i) = 1;
%     tem_rand=randperm(num-i);
%     %依次尝试将随机出来的值进行赋值（若此列已经超出阈值则换下一个随机值，直到进行额外的赋值）使用一个参数进行记录赋值次数
%         for j = (i+1) : num
%             if ismember(i,tem_rand(1,:))
%                 rand_matrix(i,j) = 1;
%             end
%         end
% end
% 
% for i = 1 : (num-1)
%     tem_rand=randperm(num-i);
%     for j = 1 : (num-1)
%         member=length(find(rand_matrix(j,:)));
%         if member < comb
%             if ismember(i,tem_rand(1,:))
%                 rand_matrix(i,j) = 1;
%             end
%         end
%     end
% end
% A=eye(num);
% B=A(randperm(num),:);
% c = (A == B);
% 
% 
% 
% 
% for j = num : -1 : 2
%     rand_matrix(j,j) = 1;
%     member=length(find(rand_matrix(j,:)));
%     if member < comb + 1
%         tem_rand=randperm(num-j);
%         tem_rand=tem_rand(1:(comb+1-member));
%         for i = j-1 : -1 : 1
%             if ismember(i,tem_rand(1,:))
%                 rand_matrix(i,j) = 1;
%             end
%         end
%     end
% end
% rand_matrix(1,1) = 1;