




a=[0.5,0.25,0.25;0.25,0.5,0.25;0.25,0.25,0.5];
inv(a);
origin=[125,4,36];%原始
tobe=origin*a;%线性处理
embed=tobe+[+0.75,-0.25,0];%嵌入（攻击前的嵌入域）
inver=embed*inv(a);%嵌入后的值
inver2=embed/a; %嵌入后的值；
inver3=a\embed; %嵌入后的值；
noise=inver2+[0.05;0.003;-0.02];%受到攻击
embed_domain=a*noise;%攻击后的嵌入域


em=sum(abs(tobe-embed));%嵌入造成的影响

real=sum(abs(inver2-origin));%实际造成的影响（嵌入实际造成的影响较大）

att=sum(abs(noise-inver2));%攻击实际造成的影响
att_doamian=sum(abs(embed_domain-embed));%攻击在嵌入域造成的影响(嵌入域受到的影响较小)


unidrnd(2,2,5)-1;