function [fitresult, gof] = createFits2_25(Save_M, Save_N, AgasFillter_Mnm_diff_avg, Agaussian_Mnm_diff_avg, Ajpeg2000_Mnm_diff_avg, gasFilltergaussianjp2000_diff)
%CREATEFITS(SAVE_M,SAVE_N,AGASFILLTER_MNM_DIFF_AVG,AGAUSSIAN_MNM_DIFF_AVG,AJPEG2000_MNM_DIFF_AVG,GASFILLTERGAUSSIANJP2000_DIFF)
%  Create fits.
%
%  Data for 'untitled fit 1' fit:
%      X Input : Save_M
%      Y Input : Save_N
%      Z Output: AgasFillter_Mnm_diff_avg
%  Data for 'untitled fit 2' fit:
%      X Input : Save_M
%      Y Input : Save_N
%      Z Output: Agaussian_Mnm_diff_avg
%  Data for 'untitled fit 3' fit:
%      X Input : Save_M
%      Y Input : Save_N
%      Z Output: Ajpeg2000_Mnm_diff_avg
%  Data for 'untitled fit 4' fit:
%      X Input : Save_M
%      Y Input : Save_N
%      Z Output: gasFilltergaussianjp2000_diff
%  Output:
%      fitresult : a cell-array of fit objects representing the fits.
%      gof : structure array with goodness-of fit info.
%
%  ������� FIT, CFIT, SFIT.

%  �� MATLAB �� 25-Feb-2023 15:13:27 �Զ�����

%% Initialization.

% Initialize arrays to store fits and goodness-of-fit.
fitresult = cell( 4, 1 );
gof = struct( 'sse', cell( 4, 1 ), ...
    'rsquare', [], 'dfe', [], 'adjrsquare', [], 'rmse', [] );

%% Fit: 'untitled fit 1'.
[xData, yData, zData] = prepareSurfaceData( Save_M, Save_N, AgasFillter_Mnm_diff_avg );

% Set up fittype and options.
ft = fittype( 'poly33' );

% Fit model to data.
[fitresult{1}, gof(1)] = fit( [xData, yData], zData, ft );

% % Plot fit with data.
% figure( 'Name', 'untitled fit 1' );
% h = plot( fitresult{1}, [xData, yData], zData );
% legend( h, 'untitled fit 1', 'AgasFillter_Mnm_diff_avg vs. Save_M, Save_N', 'Location', 'NorthEast' );
% % Label axes
% xlabel Save_M
% ylabel Save_N
% zlabel AgasFillter_Mnm_diff_avg
% grid on

%% Fit: 'untitled fit 2'.
[xData, yData, zData] = prepareSurfaceData( Save_M, Save_N, Agaussian_Mnm_diff_avg );

% Set up fittype and options.
ft = fittype( 'poly33' );

% Fit model to data.
[fitresult{2}, gof(2)] = fit( [xData, yData], zData, ft );

% % Plot fit with data.
% figure( 'Name', 'untitled fit 2' );
% h = plot( fitresult{2}, [xData, yData], zData );
% legend( h, 'untitled fit 2', 'Agaussian_Mnm_diff_avg vs. Save_M, Save_N', 'Location', 'NorthEast' );
% % Label axes
% xlabel Save_M
% ylabel Save_N
% zlabel Agaussian_Mnm_diff_avg
% grid on

%% Fit: 'untitled fit 3'.
[xData, yData, zData] = prepareSurfaceData( Save_M, Save_N, Ajpeg2000_Mnm_diff_avg );

% Set up fittype and options.
ft = fittype( 'poly33' );

% Fit model to data.
[fitresult{3}, gof(3)] = fit( [xData, yData], zData, ft );

% % Plot fit with data.
% figure( 'Name', 'untitled fit 3' );
% h = plot( fitresult{3}, [xData, yData], zData );
% legend( h, 'untitled fit 3', 'Ajpeg2000_Mnm_diff_avg vs. Save_M, Save_N', 'Location', 'NorthEast' );
% % Label axes
% xlabel Save_M
% ylabel Save_N
% zlabel Ajpeg2000_Mnm_diff_avg
% grid on
% view( -68.7, 11.9 );

%% Fit: 'untitled fit 4'.
[xData, yData, zData] = prepareSurfaceData( Save_M, Save_N, gasFilltergaussianjp2000_diff );

% Set up fittype and options.
ft = fittype( 'lowess' );
excludedPoints = excludedata( xData, yData, 'Indices', [1 2 3 4 5 6 7 8 11 12 13 26 29 30 41 56] );
opts = fitoptions( 'Method', 'LowessFit' );
opts.Normalize = 'on';
opts.Exclude = excludedPoints;

% Fit model to data.
[fitresult{4}, gof(4)] = fit( [xData, yData], zData, ft, opts );

% % Plot fit with data.
% figure( 'Name', 'untitled fit 4' );
% h = plot( fitresult{4}, [xData, yData], zData, 'Exclude', excludedPoints );
% legend( h, 'untitled fit 4', 'gasFilltergaussianjp2000_diff vs. Save_M, Save_N', 'Excluded gasFilltergaussianjp2000_diff vs. Save_M, Save_N', 'Location', 'NorthEast' );
% % Label axes
% xlabel Save_M
% ylabel Save_N
% zlabel gasFilltergaussianjp2000_diff
% grid on
% view( -0.7, 90.0 );


