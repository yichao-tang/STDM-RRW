function [matrix_a]= linear_combination(dim,y)%, BER_resize_robust, BER_gaussian_robust, BER_jpeg_robust, BER_jpeg2000_robust
% dim=5;%使用的行数和列数（矩阵大小，嵌入水印的数量）
% y=3;%每行为1的个数（每个超参数使用几个几何矩进行线性组合）
% succ=logical(true);
swapN=round(2*y*dim);%round(0.5*y*dim);
x=eye(dim);
for i=1:dim
    for j=1:y
        k=mod((i+j+1),dim)+1;
        x(i,k)=1;
    end
end
for i=1:swapN
    while true
        x1= round(rand(1,1)*(dim-1))+1;
        y1= round(rand(1,1)*(dim-1))+1;
        x2= round(rand(1,1)*(dim-1))+1;
        y2= round(rand(1,1)*(dim-1))+1;
        if (x(x1,y1)~=1 || x(x2,y2)~=1 || x(x1,y2)==x(x1,y1) || x(x2,y2)==x(x2,y1) ||...
                x1==y1 || x2==y2 || x1==y2 ||x2==y1)
            continue
        else
            temp = x(x1,y2);
            x(x1,y2)=x(x1,y1);
            x(x1,y1)=temp;
            
            temp=x(x2,y2);
            x(x2,y2)=x(x2,y1);
            x(x2,y1)=temp;
            break
        end
        tag=true
        for i=1:dim
            num=0;
            for j=1:dim
                if x(i,j)==1
                    num=num+1;
                end
            end
            if num>y+1
                tag=false
                break
            end
        end
        if tag==false
            fprintf('行不符合要求');
        else
            fprintf('行符合要求');
        end
        tag=true;
        for j=1:dim
            num=0;
            for i=1:dim
                if x(i,j)==1
                    num=num+1;
                end
            end
            if num>y+1
                tag=false
                break
            end
        end
        if tag==false
            fprintf('列不符合要求');
        else
            fprintf('列符合要求');
        end
    end
end
matrix_a = x;