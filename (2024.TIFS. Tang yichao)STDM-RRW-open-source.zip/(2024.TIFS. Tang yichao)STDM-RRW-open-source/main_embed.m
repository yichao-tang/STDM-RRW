clc;clear;
%% Parameters setting
Q=4;
spread=2;
%
%% 256bit
MODE = 1; %PCET
nMax=27;%
num=256; %bit num
Delta=50;%

% MODE = 2; %PCT
% nMax=38;%
% num=256; %bit num
% Delta=70;

% MODE = 3; %PST
% nMax=38;%
% num=256; %bit num
% Delta=60;

%% 512bit
% MODE = 1; %PCET
% nMax=38;
% num=512;%bit num
% Delta=34;

% MODE = 2; %PCT
% nMax=53;
% num=512;%bit num
% Delta=46;

% MODE = 3; %PST
% nMax=53;
% num=512;%bit num
% Delta=38;%

%% Images Reading
file_path =  'image\';
img_path_list = dir(strcat(file_path,'*.bmp'));
img_num = length(img_path_list);

if img_num > 0 
    temp=0;
    for j =1%:img_num
        image_name = img_path_list(j).name;
        image =  imread(strcat(file_path,image_name));
        % pre process
        mysize=size(image);
        if numel(mysize)>2
            if mysize(3) ==2
                image = image(:,:,1);
            else
                image=rgb2gray(image); 
            end
        end
        [image_Rows, image_Cols]=size(image);
        if image_Rows~=512 || image_Cols~=512
            image =imresize(uint8(image),[512,512]);
        end
        for Delta_tem =Delta
            for seed_num = 0
                temp=temp+1;
                                [ psnr_Iw1(temp,1), psnr_Iw2(temp,1), BER(temp,1),...
                                    BER_gaussian_robust(temp,:),...
                                    BER_jpeg_robust(temp,:), BER_jpeg2000_robust(temp,:),...
                                    BER_rotate_robust(temp,:), BER_resize_robust(temp,:),...
                                    BER_medfilt_robust(temp,:), BER_mean_robust(temp,:)]...
                                    = STDM_version(image, MODE, seed_num,  nMax, num, Delta_tem,spread,Q);
                Card(temp,:) = [j;seed_num;Delta_tem];
            end
        end
    end
end