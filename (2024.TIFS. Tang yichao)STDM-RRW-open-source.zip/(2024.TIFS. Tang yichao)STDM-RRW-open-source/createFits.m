function [fitresult, gof] = createFits(PCET_Save_N, PCET_Save_M, PCET_attack_diff, PCT_Save_N, PCT_Save_M, PCT_attack_diff, PST_Save_N, PST_Save_M, PST_attack_diff)
%CREATEFITS1(PCET_SAVE_N,PCET_SAVE_M,PCET_ATTACK_DIFF,PCT_SAVE_N,PCT_SAVE_M,PCT_ATTACK_DIFF,PST_SAVE_N,PST_SAVE_M,PST_ATTACK_DIFF)
%  Create fits.
%
%  Data for 'PCET_attack' fit:
%      X Input : PCET_Save_N
%      Y Input : PCET_Save_M
%      Z Output: PCET_attack_diff
%  Data for 'PCT_attack' fit:
%      X Input : PCT_Save_N
%      Y Input : PCT_Save_M
%      Z Output: PCT_attack_diff
%  Data for 'PST_attack' fit:
%      X Input : PST_Save_N
%      Y Input : PST_Save_M
%      Z Output: PST_attack_diff
%  Output:
%      fitresult : a cell-array of fit objects representing the fits.
%      gof : structure array with goodness-of fit info.
%
%  另请参阅 FIT, CFIT, SFIT.

%  由 MATLAB 于 05-May-2023 19:15:46 自动生成

%% Initialization.

% Initialize arrays to store fits and goodness-of-fit.
fitresult = cell( 3, 1 );
gof = struct( 'sse', cell( 3, 1 ), ...
    'rsquare', [], 'dfe', [], 'adjrsquare', [], 'rmse', [] );

%% Fit: 'PCET_attack'.
[xData, yData, zData] = prepareSurfaceData( PCET_Save_N, PCET_Save_M, PCET_attack_diff );

% Set up fittype and options.
ft = fittype( 'poly33' );
excludedPoints = excludedata( xData, yData, 'Indices', [1 2 3 4 5 6 7 8 9 10 11 12 13 26 29 30 41 56] );
opts = fitoptions( 'Method', 'LinearLeastSquares' );
opts.Exclude = excludedPoints;

% Fit model to data.
[fitresult{1}, gof(1)] = fit( [xData, yData], zData, ft, opts );

% % Plot fit with data.
% figure( 'Name', 'PCET_attack' );
% h = plot( fitresult{1}, [xData, yData], zData, 'Exclude', excludedPoints );
% legend( h, 'PCET_attack', 'PCET_attack_diff vs. PCET_Save_N, PCET_Save_M', 'Excluded PCET_attack_diff vs. PCET_Save_N, PCET_Save_M', 'Location', 'NorthEast', 'Interpreter', 'none' );
% % Label axes
% xlabel( 'PCET_Save_N', 'Interpreter', 'none' );
% ylabel( 'PCET_Save_M', 'Interpreter', 'none' );
% zlabel( 'PCET_attack_diff', 'Interpreter', 'none' );
% grid on
% view( -53.9, 8.8 );

%% Fit: 'PCT_attack'.
[xData, yData, zData] = prepareSurfaceData( PCT_Save_N, PCT_Save_M, PCT_attack_diff );

% Set up fittype and options.
ft = fittype( 'poly33' );
excludedPoints = excludedata( xData, yData, 'Indices', [1 2 3 4 5 6 7 8 9 10 15 17 23 24 31 49 61 75 101 119 138 172 194 219 263 291 319 373 405 440 500 538 575 649 689 735 814 857 909 979 1010 1036 1076 1095 1114 1135] );
opts = fitoptions( 'Method', 'LinearLeastSquares' );
opts.Exclude = excludedPoints;

% Fit model to data.
[fitresult{2}, gof(2)] = fit( [xData, yData], zData, ft, opts );

% % Create a figure for the plots.
% figure( 'Name', 'PCT_attack' );

% % Plot fit with data.
% subplot( 2, 1, 1 );
% h = plot( fitresult{2}, [xData, yData], zData, 'Exclude', excludedPoints );
% legend( h, 'PCT_attack', 'PCT_attack_diff vs. PCT_Save_N, PCT_Save_M', 'Excluded PCT_attack_diff vs. PCT_Save_N, PCT_Save_M', 'Location', 'NorthEast', 'Interpreter', 'none' );
% % Label axes
% xlabel( 'PCT_Save_N', 'Interpreter', 'none' );
% ylabel( 'PCT_Save_M', 'Interpreter', 'none' );
% zlabel( 'PCT_attack_diff', 'Interpreter', 'none' );
% grid on
% view( -0.4, 90.0 );
% 
% % Make contour plot.
% subplot( 2, 1, 2 );
% h = plot( fitresult{2}, [xData, yData], zData, 'Style', 'Contour', 'Exclude', excludedPoints );
% legend( h, 'PCT_attack', 'PCT_attack_diff vs. PCT_Save_N, PCT_Save_M', 'Excluded PCT_attack_diff vs. PCT_Save_N, PCT_Save_M', 'Location', 'NorthEast', 'Interpreter', 'none' );
% % Label axes
% xlabel( 'PCT_Save_N', 'Interpreter', 'none' );
% ylabel( 'PCT_Save_M', 'Interpreter', 'none' );
% grid on

%% Fit: 'PST_attack'.
[xData, yData, zData] = prepareSurfaceData( PST_Save_N, PST_Save_M, PST_attack_diff );

% Set up fittype and options.
ft = fittype( 'poly33' );
excludedPoints = excludedata( xData, yData, 'Indices', [1 2 3 4 5 6 7 8 9 13 14] );
opts = fitoptions( 'Method', 'LinearLeastSquares' );
opts.Exclude = excludedPoints;

% Fit model to data.
[fitresult{3}, gof(3)] = fit( [xData, yData], zData, ft, opts );

% % Plot fit with data.
% figure( 'Name', 'PST_attack' );
% h = plot( fitresult{3}, [xData, yData], zData, 'Exclude', excludedPoints );
% legend( h, 'PST_attack', 'PST_attack_diff vs. PST_Save_N, PST_Save_M', 'Excluded PST_attack_diff vs. PST_Save_N, PST_Save_M', 'Location', 'NorthEast', 'Interpreter', 'none' );
% % Label axes
% xlabel( 'PST_Save_N', 'Interpreter', 'none' );
% ylabel( 'PST_Save_M', 'Interpreter', 'none' );
% zlabel( 'PST_attack_diff', 'Interpreter', 'none' );
% grid on
% view( 6.1, 6.2 );


