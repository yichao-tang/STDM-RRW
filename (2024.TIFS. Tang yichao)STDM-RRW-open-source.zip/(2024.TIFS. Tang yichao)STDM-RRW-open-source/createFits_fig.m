function [fitresult, gof] = createFits_fig(PCET_Save_M, PCET_Save_N, PCET_gaussian_Mnm_diff_avg, PCET_jpeg2000_Mnm_diff_avg, PCET_jpeg_Mnm_diff_avg)
%CREATEFITS1(PCET_SAVE_M,PCET_SAVE_N,PCET_GAUSSIAN_MNM_DIFF_AVG,PCET_JPEG2000_MNM_DIFF_AVG,PCET_JPEG_MNM_DIFF_AVG)
%  Create fits.
%
%  Data for 'PCET_gau' fit:
%      X Input : PCET_Save_M
%      Y Input : PCET_Save_N
%      Z Output: PCET_gaussian_Mnm_diff_avg
%  Data for 'PCET_jp2000' fit:
%      X Input : PCET_Save_M
%      Y Input : PCET_Save_N
%      Z Output: PCET_jpeg2000_Mnm_diff_avg
%  Data for 'PCET_jp' fit:
%      X Input : PCET_Save_M
%      Y Input : PCET_Save_N
%      Z Output: PCET_jpeg_Mnm_diff_avg
%  Output:
%      fitresult : a cell-array of fit objects representing the fits.
%      gof : structure array with goodness-of fit info.
%
%  另请参阅 FIT, CFIT, SFIT.

%  由 MATLAB 于 06-May-2023 11:20:20 自动生成

%% Initialization.

% Initialize arrays to store fits and goodness-of-fit.
fitresult = cell( 3, 1 );
gof = struct( 'sse', cell( 3, 1 ), ...
    'rsquare', [], 'dfe', [], 'adjrsquare', [], 'rmse', [] );

%% Fit: 'PCET_gau'.
[xData, yData, zData] = prepareSurfaceData( PCET_Save_M, PCET_Save_N, PCET_gaussian_Mnm_diff_avg );

% Set up fittype and options.
ft = 'linearinterp';

% Fit model to data.
[fitresult{1}, gof(1)] = fit( [xData, yData], zData, ft, 'Normalize', 'on' );

% Plot fit with data.
figure( 'Name', 'PCET_AWGN' );
plot( fitresult{1}, [xData, yData], zData );
% Label axes
xlabel( 'PCET_L', 'Interpreter', 'none' );
ylabel( 'PCET_N', 'Interpreter', 'none' );
zlabel( 'PCET_Variation_AWGN', 'Interpreter', 'none' );
grid on
view( 60.0, 30.0 );

%% Fit: 'PCET_jp2000'.
[xData, yData, zData] = prepareSurfaceData( PCET_Save_M, PCET_Save_N, PCET_jpeg2000_Mnm_diff_avg );

% Set up fittype and options.
ft = 'linearinterp';

% Fit model to data.
[fitresult{2}, gof(2)] = fit( [xData, yData], zData, ft, 'Normalize', 'on' );

% Plot fit with data.
figure( 'Name', 'PCET_JPEG2000' );
plot( fitresult{2}, [xData, yData], zData );
% Label axes
xlabel( 'PCET_L', 'Interpreter', 'none' );
ylabel( 'PCET_N', 'Interpreter', 'none' );
zlabel( 'PCET_Variation_JPEG2000', 'Interpreter', 'none' );
grid on
view( 60.0, 30.0 );

%% Fit: 'PCET_jp'.
[xData, yData, zData] = prepareSurfaceData( PCET_Save_M, PCET_Save_N, PCET_jpeg_Mnm_diff_avg );

% Set up fittype and options.
ft = 'linearinterp';

% Fit model to data.
[fitresult{3}, gof(3)] = fit( [xData, yData], zData, ft, 'Normalize', 'on' );

% Plot fit with data.
figure( 'Name', 'PCET_JPEG' );
plot( fitresult{3}, [xData, yData], zData );
% Label axes
xlabel( 'PCET_L', 'Interpreter', 'none' );
ylabel( 'PCET_N', 'Interpreter', 'none' );
zlabel( 'PCET_Variation_JPEG', 'Interpreter', 'none' );
grid on
view( 60.0, 30.0 );

%% Fit: 'PCET_attack'.
% [xData, yData, zData] = prepareSurfaceData( PCET_Save_N, PCET_Save_M, PCET_attack_diff );
% 
% % Set up fittype and options.
% ft = fittype( 'poly33' );
% opts = fitoptions( 'Method', 'LinearLeastSquares' );
% opts.Robust = 'Bisquare';
% 
% % Fit model to data.
% [fitresult{1}, gof(1)] = fit( [xData, yData], zData, ft, opts );
% 
% % Plot fit with data.
% figure( 'Name', 'PCET_attack' );
% plot( fitresult{1}, [xData, yData], zData );
% % Label axes
% xlabel( 'PCET_L', 'Interpreter', 'none' );
% ylabel( 'PCET_N', 'Interpreter', 'none' );
% zlabel( 'PCET_Attack_Mnl_diff_avg', 'Interpreter', 'none' );
% grid on
% view( -30, 30 );

