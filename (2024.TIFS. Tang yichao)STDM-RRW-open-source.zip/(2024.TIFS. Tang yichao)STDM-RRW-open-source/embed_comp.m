function new_a=embed_comp(old_a,Q1,new_length)
% noval_a%新的向量
% old_a = [1,2];%老的向量
% Q1 = [2,3];%投影向量
% % % 定义点乘结果
% new_length = 9;%新的投影长度
% 求解夹角
%  old_a =[1+2i,2+4i];
%  Q1 = [1,1];
%  new_length = 3;
theta = acos(dot(old_a,Q1)/(norm(old_a)*norm(Q1)));
norm_noval_a=new_length/(cos(theta)*norm(Q1));

new_a=old_a*(norm_noval_a/norm(old_a));